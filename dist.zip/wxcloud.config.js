/** @type {import("@wxcloud/core").CloudConfig} */
const cloudConfig = {
  server: ".",
  type: "universal"
}

module.exports = cloudConfig
