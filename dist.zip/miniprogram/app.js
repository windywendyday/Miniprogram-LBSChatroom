// app.js
App({
  onLaunch: async function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力');
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        env: 'lbschatroom-0gjko5o76144c24e',
        traceUser: true,
      });
    //   wx.cloud.callContainer({
    //     "config": {
    //       "env": "prod-6gqde8rzdaa25908"
    //     },
    //     "path": "/api/count",
    //     "header": {
    //       "X-WX-SERVICE": "express-5a53"
    //     },
    //     "method": "POST",
    //     "data": {
    //       "action": "inc"
    //     }
    //     })
    //     const { socketTask } = await wx.cloud.connectContainer({
    //         config: {
    //         env: 'prod-6gqde8rzdaa25908', // 替换自己的微信云托管的环境ID
    //         },
    //         service: 'lbschatroom', // 替换自己的服务名
    //         path: '/' // 不填默认根目录
    //     })
    //     socketTask.onMessage(function (res) {
    //         console.log('【WEBSOCKET】', res.data)
    //     })
    //     socketTask.onOpen(function (res) {
    //     console.log('【WEBSOCKET】', '链接成功！')
    //     socketTask.send({
    //         data: '这是小程序消息'
    //     })
    //     })
    //     socketTask.onClose(function (res) {
    //     console.log('【WEBSOCKET】链接关闭！')
    //     })
    }

    this.globalData = {};
  }
  
});
