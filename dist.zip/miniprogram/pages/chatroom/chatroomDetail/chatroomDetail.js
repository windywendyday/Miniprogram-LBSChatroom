// pages/chatroom/chatroom.js
const db = wx.cloud.database().collection('conversations')
const watcher = wx.cloud.database().collection('conversations')
    .where({
        roomID:1
    })
    .watch({
        onChange:function(snapshot){
            console.log('docs\'s changed events', snapshot.docChanges)
            console.log('query result snapshot after the event', snapshot.docs)
            console.log('is init data', snapshot.type === 'init')
        },
        onError: function(err) {
            console.error('the watch closed because of error', err)
        }
    })
  
Page({
    /**
     * 页面的初始数据
     */
    data: {
        condition:true,
        schoolID:'',
        avatar:'',
        conversations:[],
        value:'',
        message:'',
        isBlur: false,
        roomID:''
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        wx.hideTabBar()
        this.getOpenerEventChannel().once('getUserInfo',({schoolID, roomID}) => {
            this.setData({
                schoolID: schoolID,
                roomID: roomID
            })
        })
    },
    handleInput(){
    },
    handleBlur(){
    },
    handleConfirm(e){
        this.setData({
            message:e.detail.value,
            value:'',
        })
        console.log(this.data.message)
        db.add({
            data:{
                from: this.data.schoolID,
                message: this.data.message,
                timestamp: new Date().getTime(),
                roomID: this.data.roomID
            }
        })
    },
    showMoreMenu(){
        console.log('调用函数');
        if(this.data.condition){
            this.setData({
                condition:false
            })
        }
       else {
            this.setData({
                condition:true
            })
        }

    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    // getConversationsItem(item) {
    //     let {latestMsg, ...msg} = item;
    //     return Object.assign(msg, JSON.parse(latestMsg));
    // }
    onUnload(){
        watcher.close()
    }

})